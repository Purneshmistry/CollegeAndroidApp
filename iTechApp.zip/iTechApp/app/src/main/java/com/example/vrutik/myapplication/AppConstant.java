package com.example.vrutik.myapplication;

public class AppConstant {

    public static final String FIREBASE_USERS="users";
}
