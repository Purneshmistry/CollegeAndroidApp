package com.example.vrutik.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;

public class SignUpActivity extends Activity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    private ImageView back_btn_signup;
    private EditText ussernameED;
    private EditText emailED;
    private EditText enrollmentED;
    private EditText phoneED;
    private Spinner semesterSpinner;
    private EditText passwordED;
    private EditText cnfrmpswdED;
    private Spinner deptspinner;


    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private Button signupbtn;
    private static final int PICK_IMG_CODE = 100;
    private static final int TAKE_IMG_CODE = 101;
    private CircleImageView profileUpload;
    private FirebaseStorage firebaseStorage;
    private StorageReference storageReference;
    private Uri selectedFileIntent;
    private String department;
    private String semester;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.signup_activity);

        firebaseStorage = FirebaseStorage.getInstance ( );
        storageReference = firebaseStorage.getReference ( );
        firebaseAuth = FirebaseAuth.getInstance ( );
        firebaseDatabase = FirebaseDatabase.getInstance ( );
        databaseReference = firebaseDatabase.getReference ( );
        ussernameED = findViewById (R.id.username_signup);
        emailED = findViewById (R.id.email_signup);
        enrollmentED = findViewById (R.id.enrollment_signup);
        phoneED = findViewById (R.id.phone_no_signup);
        semesterSpinner = findViewById (R.id.semester_list_signup_spinner);
        passwordED = findViewById (R.id.password_signup);
        cnfrmpswdED = findViewById (R.id.confirm_psswd_signup);
        deptspinner = findViewById (R.id.department_list_signup_spinner);
        signupbtn = findViewById (R.id.signup_main_btn);
        profileUpload = findViewById (R.id.profile_select);

        back_btn_signup = findViewById (R.id.back_btn);
        back_btn_signup.setOnClickListener (this);
        signupbtn.setOnClickListener (this);
        profileUpload.setOnClickListener (this);

        semesterSpinner.setOnItemSelectedListener (this);
        deptspinner.setOnItemSelectedListener (this);


    }

    @Override
    public void onClick(View v) {

        switch (v.getId ( )) {
            case R.id.back_btn:
                back_btn_event ( );
                break;
            case R.id.signup_main_btn:
                signUPbtn ( );
                break;
            case R.id.profile_select:
                uploadImg ( );
                break;
        }

    }

    private void uploadImg() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && ContextCompat.checkSelfPermission (this,
                android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions (this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            return;
        } //creating an intent for file chooser

//        Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//        startActivityForResult(takePicture, TAKE_IMG_CODE);

        Intent intent = new Intent ( );
        intent.setType ("image/*");
        intent.setAction (Intent.ACTION_GET_CONTENT);
        startActivityForResult (Intent.createChooser (intent, "Select Picture"), PICK_IMG_CODE);



    }



    private void insertDataInToDb(Uri uri) {

        databaseReference.child ("image").push ( )
                .setValue (new ImageModel (uri.toString ( )), new DatabaseReference.CompletionListener ( ) {
                    @Override
                    public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {

                        if (databaseError != null) {
                            Toast.makeText (SignUpActivity.this, "Error" + databaseError.getMessage ( ), Toast.LENGTH_SHORT).show ( );
                        } else {
                            Toast.makeText (SignUpActivity.this, "Data Inserted", Toast.LENGTH_SHORT).show ( );
                        }

                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult (requestCode, resultCode, data);

//        switch(requestCode){
//            case PICK_IMG_CODE:
//                if(resultCode == PICK_IMG_CODE){
//                    Uri selectedImage = data.getData();
//                    profileUpload.setImageURI(selectedImage);
//                    break;
//            case TAKE_IMG_CODE:
//                if(resultCode == TAKE_IMG_CODE){
//                    Uri selectedImage = data.getData();
//                    profileUpload.setImageURI(selectedImage);
//                break;
//                }
        if (requestCode == PICK_IMG_CODE
                && resultCode == RESULT_OK && data != null && data.getData ( ) != null) {
            //if a file is selected
            if (data.getData ( ) != null) {
                //uploading the file
                File file = new File (data.getData ( ).getPathSegments ( ).toString ( ));
                selectedFileIntent = data.getData ( );
                profileUpload.setImageURI (selectedFileIntent);
            } else {
                Toast.makeText (this, "No file chosen", Toast.LENGTH_SHORT).show ( );
            }
        }
    }

    private void signUPbtn() {
        final String username_signup = ussernameED.getText ( ).toString ( ).trim ( );
        final String email_signup = emailED.getText ( ).toString ( ).trim ( );
        final String password_signup = passwordED.getText ( ).toString ( ).trim ( );
        String cnfrmpassword_signup = cnfrmpswdED.getText ( ).toString ( ).trim ( );
        final String phonenum = phoneED.getText ( ).toString ( ).trim ( );
        final String enrollmentno = enrollmentED.getText ( ).toString ( ).trim ( );


        if (email_signup.isEmpty ( ) || password_signup.isEmpty ( ) || username_signup.isEmpty ( ) || phonenum.isEmpty ( )
                || enrollmentno.isEmpty ( )) {
            Toast.makeText (this, "Enter Details", Toast.LENGTH_SHORT).show ( );
        } else if (!cnfrmpassword_signup.equals (password_signup)) {
            Toast.makeText (this, "Both Password Doesn't Match", Toast.LENGTH_SHORT).show ( );
        } else {
            firebaseAuth.createUserWithEmailAndPassword (email_signup, password_signup)
                    .addOnCompleteListener (new OnCompleteListener <AuthResult> ( ) {
                        @Override
                        public void onComplete(@NonNull Task <AuthResult> task) {
                            if (task.isSuccessful ( )) {
                                Toast.makeText (SignUpActivity.this, "SignUp Success", Toast.LENGTH_SHORT).show ( );
                                insertUserToDatabase (email_signup, password_signup, username_signup, phonenum, enrollmentno);
                                final Intent loginactivity = new Intent (SignUpActivity.this, LoginActivity.class);
                                startActivity (loginactivity);
                            } else {
                                Toast.makeText (SignUpActivity.this, "" + task.getException ( ), Toast.LENGTH_SHORT).show ( );
                            }
                        }
                    });
        }

        if (selectedFileIntent != null) {

            final StorageReference sRef = storageReference.child ("ProfileImage/" + UUID.randomUUID ( ).toString ( ));

            sRef.putFile (selectedFileIntent)
                    .addOnSuccessListener (new OnSuccessListener <UploadTask.TaskSnapshot> ( ) {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Toast.makeText (SignUpActivity.this, "Uploaded", Toast.LENGTH_SHORT).show ( );

                            sRef.getDownloadUrl ( ).addOnSuccessListener (new OnSuccessListener <Uri> ( ) {
                                @Override
                                public void onSuccess(Uri uri) {
                                    insertDataInToDb (uri);
                                }
                            });

                        }
                    });
        }

    }

    private void insertUserToDatabase(String email_signup, String password_signup, String username_signup, String phonenum, String enrollmentno) {

        databaseReference
                .child (AppConstant.FIREBASE_USERS)
                .child (firebaseAuth.getUid ( ))
                .setValue (new SignUpUserModel (email_signup, password_signup, username_signup, phonenum, enrollmentno, semester, department, false), new DatabaseReference.CompletionListener ( ) {
                    @Override
                    public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {

                        if (databaseError != null) {
                            Toast.makeText (SignUpActivity.this, "" + databaseError.getMessage ( ), Toast.LENGTH_SHORT).show ( );
                        } else {
                            Toast.makeText (SignUpActivity.this, "Database Inserted", Toast.LENGTH_SHORT).show ( );
                        }
                    }
                });
    }

    private void back_btn_event() {

        Intent gotoMainActivity = new Intent (SignUpActivity.this, MainActivity.class);
        startActivity (gotoMainActivity);
    }

    @Override
    public void onItemSelected(AdapterView <?> parent, View view, int position, long id) {

        switch (parent.getId ( )) {
            case R.id.department_list_signup_spinner:
                department = parent.getSelectedItem ( ).toString ( );
                //Toast.makeText (this, "" + department, Toast.LENGTH_SHORT).show ( );
                break;
            case R.id.semester_list_signup_spinner:
                semester = parent.getSelectedItem ( ).toString ( );
                //Toast.makeText (this, "" + semester, Toast.LENGTH_SHORT).show ( );
                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView <?> parent) {

    }
}
