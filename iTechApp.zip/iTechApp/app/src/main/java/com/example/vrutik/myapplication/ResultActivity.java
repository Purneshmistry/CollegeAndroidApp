package com.example.vrutik.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {

    private ArrayList<ResultUserModel> arrayList;
    private ResultActivity_RecyclerView resultAdapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result_activity);

        recyclerView=findViewById(R.id.result_page_recycleview);

        arrayList=new ArrayList<ResultUserModel>();
        arrayList.add(new ResultUserModel("March 10,2018","4th Semester",
                "TOP 10 GTU RESULT LIST"));
        arrayList.add(new ResultUserModel("July 21,2018","2nd Semester",
                "MIDSEM RESULT LIST"));
        arrayList.add(new ResultUserModel("January 3,2018","3rd Semester",
                "TOP 10 GTU RESULT LIST (CPI wise)"));
        arrayList.add(new ResultUserModel("September 16,2018","6th Semester",
                "TOP 10 GTU RESULT LIST (SPI wise)"));
        arrayList.add(new ResultUserModel("March 19,2018","1st Semester",
                "MIDSEM RESULT LIST"));

        resultAdapter=new ResultActivity_RecyclerView(arrayList);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(ResultActivity.this,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(resultAdapter);
    }
}
