package com.example.vrutik.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends Activity implements View.OnClickListener {

    private ImageView login_back_btn;
    private TextView Forgot_password_tv;
    private Button login_main_btn;
    private EditText usernameED;
    private EditText passwordED;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        firebaseAuth = FirebaseAuth.getInstance();

        usernameED = findViewById(R.id.username_main_login);
        passwordED = findViewById(R.id.pswd_main_login);

        login_back_btn = findViewById(R.id.back_btn);
        login_back_btn.setOnClickListener(this);

        Forgot_password_tv = findViewById(R.id.forgot_login_activity_tv);
        Forgot_password_tv.setOnClickListener(this);

        login_main_btn = findViewById(R.id.login_main_btn);
        login_main_btn.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.back_btn:
                back_btn();
                break;

            case R.id.forgot_login_activity_tv:
                forgot_password_login_activity_tv();
                break;

            case R.id.login_main_btn:
                login_main_btn();
                break;
        }
    }

    private void login_main_btn() {
        final Intent gotohome = new Intent(LoginActivity.this,HomeActivity.class);
        startActivity(gotohome);

//        String username = usernameED.getText().toString().trim();
//        String pswd = passwordED.getText().toString().trim();
//
//        if(username.isEmpty() || pswd.isEmpty()){
//            Toast.makeText(this, "Enter Details", Toast.LENGTH_SHORT).show();
//        }else {
//            firebaseAuth.signInWithEmailAndPassword(username,pswd)
//                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                        @Override
//                        public void onComplete(@NonNull Task<AuthResult> task) {
//                            if(task.isSuccessful()){
//                                final Intent gotohome = new Intent(LoginActivity.this,HomeActivity.class);
//                                startActivity(gotohome);
//                                Toast.makeText(LoginActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
//                            }else{
//                                Toast.makeText(LoginActivity.this, "Email or Password Invlaid", Toast.LENGTH_SHORT).show();
//                            }
//                        }
//                    });

//        }

    }

    private void forgot_password_login_activity_tv() {

        Intent gotoForgotActivity = new Intent(LoginActivity.this, ForgotActivity.class);
        startActivity(gotoForgotActivity);
    }


    private void back_btn() {

        Intent gotoMainActivity = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(gotoMainActivity);

    }
}
