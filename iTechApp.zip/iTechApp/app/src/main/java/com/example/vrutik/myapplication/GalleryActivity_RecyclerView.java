package com.example.vrutik.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class GalleryActivity_RecyclerView extends RecyclerView.Adapter <GalleryActivity_RecyclerView.MyViewHolder> {

    private ArrayList <ImgUserModel> arrayList;
    private Context context;

    public GalleryActivity_RecyclerView(ArrayList <ImgUserModel> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private ImageView img_title;

        public MyViewHolder(View itemView) {
            super (itemView);
            img_title = itemView.findViewById (R.id.gallery_img);

        }

        public void setdata(ImgUserModel imgUserModel) {

            Log.e ("JHIL",imgUserModel.getImageURL ());
            Glide.with (context)
                    .load (imgUserModel.getImageURL ( ))
                    .apply (new RequestOptions ( ).placeholder (R.mipmap.ic_launcher))
                    .into (img_title);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from (parent.getContext ( )).inflate (R.layout.gallery_post_activity, parent, false);
        return new MyViewHolder (view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        ImgUserModel imgUserModel = arrayList.get (position);
        holder.setdata (imgUserModel);

    }

    @Override
    public int getItemCount() {
        return arrayList.size ( );
    }


}
