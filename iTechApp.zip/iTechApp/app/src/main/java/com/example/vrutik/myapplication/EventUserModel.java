package com.example.vrutik.myapplication;

public class EventUserModel {

    private String event_month;
    private String event_date;
    private String event_title;
    private String event_description;


    public EventUserModel(String event_month, String event_date, String event_title, String event_description) {
        this.event_month = event_month;
        this.event_date = event_date;
        this.event_title = event_title;
        this.event_description = event_description;
    }

    public EventUserModel() {
    }

    public String getEvent_month() {
        return event_month;
    }

    public void setEvent_month(String event_month) {
        this.event_month = event_month;
    }

    public String getEvent_date() {
        return event_date;
    }

    public void setEvent_date(String event_date) {
        this.event_date = event_date;
    }

    public String getEvent_title() {
        return event_title;
    }

    public void setEvent_title(String event_title) {
        this.event_title = event_title;
    }

    public String getEvent_description() {
        return event_description;
    }

    public void setEvent_description(String event_description) {
        this.event_description = event_description;
    }
}
