package com.example.vrutik.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotActivity extends Activity implements View.OnClickListener {

    ImageView back_btn;
    private EditText forgotpasswordED;
    private Button resetbtn;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forget_activity);
        firebaseAuth = FirebaseAuth.getInstance();
        forgotpasswordED = findViewById(R.id.Forgot_activity_emailid_ed);
        back_btn=findViewById(R.id.forgot_back_btn);
        resetbtn = findViewById(R.id.forgot_activity_reset_btn);
        forgotpasswordED = findViewById(R.id.Forgot_activity_emailid_ed);

        resetbtn.setOnClickListener(this);
        back_btn.setOnClickListener(this);
        forgotpasswordED.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.forgot_back_btn:
                backbtn();
                break;
            case R.id.forgot_activity_reset_btn:
                forgotpassword();
                break;
        }
    }

    private void forgotpassword() {
        String emailsend = forgotpasswordED.getText().toString().trim();

        if(emailsend.isEmpty()){
            Toast.makeText(this, "Please enter the email", Toast.LENGTH_SHORT).show();
        }else{
            firebaseAuth.sendPasswordResetEmail(emailsend)
                    .addOnCompleteListener(ForgotActivity.this, new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                final Intent backtologin = new Intent(ForgotActivity.this,LoginActivity.class);
                                startActivity(backtologin);
                                Toast.makeText(ForgotActivity.this, "Email sent", Toast.LENGTH_SHORT).show();
                            }else{
                                Toast.makeText(ForgotActivity.this, ""+task.getException(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }

    private void backbtn() {
        final Intent backtologin = new Intent(ForgotActivity.this,LoginActivity.class);
        startActivity(backtologin);
    }
}
