package com.example.vrutik.myapplication;

public class PostUserModel {
    
    private String title;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public PostUserModel(String title) {
        this.title = title;
    }

    public PostUserModel() {
    }
}
