package com.example.vrutik.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class EventActivity extends AppCompatActivity {

    private ArrayList<EventUserModel> userModelArrayList;
    private RecyclerView recyclerView;
    private EventActivity_RecyclerView eventAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_activity);

        recyclerView=findViewById(R.id.event_page_recycleview);
        userModelArrayList = new ArrayList<EventUserModel>();

        userModelArrayList.add(new EventUserModel("Feb","20","TechFest-2019",
                "IT department has conducted TECHFEST full of technical events along with non-technical events." ));

        userModelArrayList.add(new EventUserModel("Jan", "10","Tender Talks",
                "It is an small event organised for IT department having some trending topics related Debate."));

        userModelArrayList.add(new EventUserModel("Feb","9","PLACEMENT FAIR",
                "A placement week event is being planned wherein all aspirant students and prospective industries are going to meet for the placement..."));

        userModelArrayList.add(new EventUserModel("Jan", "25","REPULIC DAY",""));

        userModelArrayList.add(new EventUserModel("Jan", "10","Tender Talks",
                "It is an small event organised for IT department having some trending topics related Debate."));

        userModelArrayList.add(new EventUserModel("Feb","9","PLACEMENT FAIR",
                "A placement week event is being planned wherein all aspirant students and prospective industries are going to meet for the placement..."));

        userModelArrayList.add(new EventUserModel("Jan", "25","REPULIC DAY",""));

        userModelArrayList.add(new EventUserModel("Jan", "10","Tender Talks",
                "It is an small event organised for IT department having some trending topics related Debate."));

        userModelArrayList.add(new EventUserModel("Feb","9","PLACEMENT FAIR",
                "A placement week event is being planned wherein all aspirant students and prospective industries are going to meet for the placement..."));

        userModelArrayList.add(new EventUserModel("Jan", "25","REPULIC DAY",""));

        eventAdapter = new EventActivity_RecyclerView(userModelArrayList);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(EventActivity.this,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(eventAdapter);
    }
}
