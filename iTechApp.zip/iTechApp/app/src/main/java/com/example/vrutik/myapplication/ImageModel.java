package com.example.vrutik.myapplication;

public class ImageModel {

    private String imgUrl;

    public ImageModel(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
