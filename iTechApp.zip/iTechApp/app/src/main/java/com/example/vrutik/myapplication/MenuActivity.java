package com.example.vrutik.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class MenuActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView backimgviewclick;
    private CardView result,ematerial,map,event,link,gallery;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity);

        backimgviewclick = findViewById(R.id.back_btn);
        backimgviewclick.setOnClickListener(this);
        result=findViewById(R.id.menu_result_view);
        result.setOnClickListener(this);
        ematerial=findViewById(R.id.menu_ematerial_view);
        ematerial.setOnClickListener(this);
        map=findViewById(R.id.menu_map_view);
        map.setOnClickListener(this);
        event=findViewById(R.id.menu_event_view);
        event.setOnClickListener(this);
        link=findViewById(R.id.menu_link_view);
        link.setOnClickListener(this);
        gallery=findViewById(R.id.menu_gallery_view);
        gallery.setOnClickListener(this);

        BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
                = new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        Home_navigation_post_activity();
                        break;
                    case R.id.navigation_dashboard:
                        Link_navigation_post_activity();
//                    mTextMessage.setText(R.string.title_dashboard);
                        break;
                    case R.id.navigation_notifications:
//                    mTextMessage.setText(R.string.title_notifications);
                        break;
                }
                return false;
            }

        };

//        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
//        Menu menu = navigation.getMenu();
//        MenuItem menuItem = menu.getItem(1);
//        menuItem.setChecked(false);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    }

    private void Link_navigation_post_activity() {
        final Intent linkactivity = new Intent(MenuActivity.this,LinkActivity.class);
        startActivity(linkactivity);
    }

    private void Home_navigation_post_activity() {
        final Intent homeactivity = new Intent(MenuActivity.this,HomeActivity.class);
        startActivity(homeactivity);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_btn:
                final Intent gotback = new Intent(MenuActivity.this,HomeActivity.class);
                startActivity(gotback);
                break;

            case R.id.menu_result_view:
                final Intent gotoresultactivity = new Intent(MenuActivity.this,ResultActivity.class);
                startActivity(gotoresultactivity);
                break;

            case R.id.menu_ematerial_view:
                final Intent gotoematerialtactivity = new Intent(MenuActivity.this,EmaterialActivity.class);
                startActivity(gotoematerialtactivity);
                break;

            case R.id.menu_map_view:
                final Intent gotomapactivity = new Intent(MenuActivity.this,MapsActivity.class);
                startActivity(gotomapactivity);
                break;

            case R.id.menu_event_view:
                final Intent gotoeventactivity = new Intent(MenuActivity.this,EventActivity.class);
                startActivity(gotoeventactivity);
                break;

            case R.id.menu_link_view:
                final Intent gotolinkactivity = new Intent(MenuActivity.this,LinkActivity.class);
                startActivity(gotolinkactivity);
                break;

            case R.id.menu_gallery_view:
                final Intent gotogalleryactivity = new Intent(MenuActivity.this,GalleryActivity.class);
                startActivity(gotogalleryactivity);
                break;
        }
    }
}
