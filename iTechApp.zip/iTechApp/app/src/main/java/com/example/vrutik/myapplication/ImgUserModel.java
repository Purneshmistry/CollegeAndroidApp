package com.example.vrutik.myapplication;

public class ImgUserModel {

    private String ImageURL;
    private String ImageCaption;


    public ImgUserModel() {
    }


    public ImgUserModel(String imageURL, String imageCaption) {
        ImageURL = imageURL;
        ImageCaption = imageCaption;
    }

    public String getImageCaption() {
        return ImageCaption;
    }

    public void setImageCaption(String imageCaption) {
        ImageCaption = imageCaption;
    }

    public String getImageURL() {
        return ImageURL;
    }

    public void setImageURL(String imageURL) {
        this.ImageURL = imageURL;
    }
}
