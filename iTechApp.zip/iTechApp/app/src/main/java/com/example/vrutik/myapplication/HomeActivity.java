package com.example.vrutik.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    private RecyclerView post_recycler_view;
    private ArrayList<PostUserModel> userModelArrayList;
    private PostActivity_RecyclerView postActivityRecyclerView;
    DrawerLayout drawerLayout;
    android.support.v7.widget.Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_navigation_activity);

        post_recycler_view = findViewById(R.id.main_activity_post);
        userModelArrayList = new ArrayList<>();
        userModelArrayList.add(new PostUserModel("Java"));
        userModelArrayList.add(new PostUserModel("Javascript"));
        userModelArrayList.add(new PostUserModel("Phython"));
        userModelArrayList.add(new PostUserModel("C++"));
        userModelArrayList.add(new PostUserModel("Swift"));
        userModelArrayList.add(new PostUserModel("Android"));
        userModelArrayList.add(new PostUserModel("PHP"));
        userModelArrayList.add(new PostUserModel("Perl"));

        postActivityRecyclerView = new PostActivity_RecyclerView(userModelArrayList);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(HomeActivity.this,LinearLayoutManager.VERTICAL,false);
        post_recycler_view.setLayoutManager(layoutManager);
        post_recycler_view.setAdapter(postActivityRecyclerView);


        NavigationView navigationView = (NavigationView) findViewById(R.id.drawer_navigation);
        navigationView.setNavigationItemSelectedListener(this);

        drawer_method();


        BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
                = new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        Home_navigation_post_activity();
                        break;
                    case R.id.navigation_dashboard:
                        Link_navigation_post_activity();
                        break;
                    case R.id.navigation_notifications:
                        break;
                }
                return false;
            }

        };

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    }

    private void Link_navigation_post_activity() {
        final Intent linkactivity = new Intent(HomeActivity.this,LinkActivity.class);
        startActivity(linkactivity);
    }

    private void drawer_method() {

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.main_toolbar);

        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(HomeActivity.this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
//        actionBarDrawerToggle.setDrawerIndicatorEnabled(false);
//        actionBarDrawerToggle.setHomeAsUpIndicator(R.drawable.ic_person_black_24dp);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

    }

    private void Home_navigation_post_activity() {

    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_icon:
                final Intent intent_menu = new Intent(HomeActivity.this,MenuActivity.class);
                startActivity(intent_menu);
                //overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_in);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.

        switch (item.getItemId()){
            case R.id.navigation_profile:
                final Intent intent_profile_edit = new Intent(HomeActivity.this,EditProfileActivity.class);
                startActivity(intent_profile_edit);
                break;

            case R.id.navigation_reset_password:
                gotoresetpassword();
                break;

            case R.id.navigation_logout:
                gotologin();
                break;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void gotologin() {
        final Intent loginactivity = new Intent(HomeActivity.this,LoginActivity.class);
        startActivity(loginactivity);
    }

    private void gotoresetpassword() {
        final Intent gotoresetpassword = new Intent(HomeActivity.this,ForgotActivity.class);
        startActivity(gotoresetpassword);
    }
}
