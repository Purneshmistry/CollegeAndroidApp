package com.example.vrutik.myapplication;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class ResultActivity_RecyclerView extends RecyclerView.Adapter<ResultActivity_RecyclerView.Result_ViewHolder> {

    private ArrayList<ResultUserModel> arrayList;

    public ResultActivity_RecyclerView(ArrayList<ResultUserModel> arrayList) {
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public Result_ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.result_post_activity,parent,false);
        return new Result_ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Result_ViewHolder holder, int position) {
        ResultUserModel resultUserModel=arrayList.get(position);
        holder.result_date.setText(resultUserModel.getResult_date());
        holder.result_title.setText(resultUserModel.getResult_title());
        holder.result_sem.setText(resultUserModel.getResult_sem());

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class Result_ViewHolder extends RecyclerView.ViewHolder {

        private TextView result_date;
        private TextView result_title;
        private TextView result_sem;
        public Result_ViewHolder(View itemView) {
            super(itemView);
            result_date=itemView.findViewById(R.id.result_post_date_tv);
            result_sem=itemView.findViewById(R.id.result_post_semester_tv);
            result_title=itemView.findViewById(R.id.result_post_title_tv);
        }
    }
}
