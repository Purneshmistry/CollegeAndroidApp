package com.example.vrutik.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.customtabs.CustomTabsIntent;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;

public class LinkActivity extends AppCompatActivity implements View.OnClickListener {
    private RecyclerView post_recycler_view;
    private Button sbiLinkbtn;
    private Button GtuResultlinkbtn;
    private Button GtuWebsitelinkbtn;
    private Button Scholarsgiplinkbtn;
    private ImageView Link_backimgviewclick;
    Uri uri;
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.link_activity);

        Link_backimgviewclick = findViewById(R.id.back_btn);
        Link_backimgviewclick.setOnClickListener(this);

        sbiLinkbtn=findViewById(R.id.sbi);
        sbiLinkbtn.setOnClickListener(this);

        GtuResultlinkbtn = findViewById(R.id.link_activity_gturesultlink);
        GtuResultlinkbtn.setOnClickListener(this);

        GtuWebsitelinkbtn = findViewById(R.id.link_activity_gtuwebsitelink);
        GtuWebsitelinkbtn.setOnClickListener(this);

        Scholarsgiplinkbtn = findViewById(R.id.link_activity_scholarship);
        Scholarsgiplinkbtn.setOnClickListener(this);

        BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
                = new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        Home_navigation_post_activity();
                        break;
                    case R.id.navigation_dashboard:
                        Link_navigation_post_activity();
//                    mTextMessage.setText(R.string.title_dashboard);
                        break;
                    case R.id.navigation_notifications:
//                    mTextMessage.setText(R.string.title_notifications);
                        break;
                }
                return false;
            }

        };

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        Menu menu = navigation.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

    private void Link_navigation_post_activity() {
    }

    private void Home_navigation_post_activity() {
        final Intent homeactivity = new Intent(LinkActivity.this,HomeActivity.class);
        startActivity(homeactivity);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.sbi:
                sbilink();
                break;
            case R.id.link_activity_gturesultlink:
                GtuResultlink();
                break;
            case R.id.link_activity_gtuwebsitelink:
                Gtuwebsitelink();
                break;
            case R.id.link_activity_scholarship:
                Scholarshiplink();
                break;
            case R.id.back_btn:
                startActivity(new Intent(LinkActivity.this,HomeActivity.class));
                break;
        }
    }

    private void Scholarshiplink() {
        String url = "https://www.digitalgujarat.gov.in";
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setToolbarColor(ContextCompat.getColor(LinkActivity.this,R.color.linktoolbarcolor));
        builder.addDefaultShareMenuItem();
        CustomTabsIntent customTabsIntent = builder.build();
        customTabsIntent.launchUrl(this, Uri.parse(url));

    }

    private void Gtuwebsitelink() {
        String url = "https://www.gtu.ac.in/";
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setToolbarColor(ContextCompat.getColor(LinkActivity.this,R.color.linktoolbarcolor));
        builder.addDefaultShareMenuItem();
        CustomTabsIntent customTabsIntent = builder.build();
        customTabsIntent.launchUrl(this, Uri.parse(url));

    }

    private void GtuResultlink() {
        String url = "https://www.gturesults.in/";
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setToolbarColor(ContextCompat.getColor(LinkActivity.this,R.color.linktoolbarcolor));
        builder.addDefaultShareMenuItem();
        CustomTabsIntent customTabsIntent = builder.build();
        customTabsIntent.launchUrl(this, Uri.parse(url));

    }

    private void sbilink() {
        String url = "https://www.onlinesbi.com/sbicollect/icollecthome.htm";
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setToolbarColor(ContextCompat.getColor(LinkActivity.this,R.color.linktoolbarcolor));
        builder.addDefaultShareMenuItem();
        CustomTabsIntent customTabsIntent = builder.build();
        customTabsIntent.launchUrl(this, Uri.parse(url));
    }

}
