package com.example.vrutik.myapplication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

public class BottomActivity extends AppCompatActivity {

    RecyclerView post_recycler_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bottom_activity);

        BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
                = new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        Home_navigation_post_activity();
                        return true;
                    case R.id.navigation_dashboard:
                        Link_navigation_post_activity();
//                    mTextMessage.setText(R.string.title_dashboard);
                        return true;
                    case R.id.navigation_notifications:
//                    mTextMessage.setText(R.string.title_notifications);
                        return true;
                }
                return false;
            }

        };

//        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

    private void Link_navigation_post_activity() {
        final Intent linkactivity = new Intent(BottomActivity.this,LinkActivity.class);
        startActivity(linkactivity);
    }

    private void Home_navigation_post_activity() {
        final Intent homeactivity = new Intent(BottomActivity.this,HomeActivity.class);
        startActivity(homeactivity);

    }
}
