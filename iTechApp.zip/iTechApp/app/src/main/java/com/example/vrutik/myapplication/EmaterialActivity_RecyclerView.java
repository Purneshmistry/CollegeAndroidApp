package com.example.vrutik.myapplication;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class EmaterialActivity_RecyclerView extends RecyclerView.Adapter<EmaterialActivity_RecyclerView.MyViewholder> {

    private ArrayList<EmaterialUserModel> arrayList;

    public EmaterialActivity_RecyclerView(ArrayList<EmaterialUserModel> arrayList) {
        this.arrayList = arrayList;
    }
    public class MyViewholder extends RecyclerView.ViewHolder
    {
        private TextView ematerial_date;
        private TextView ematerial_title;
        private TextView ematerial_sub;
        public MyViewholder(@NonNull View itemView) {
            super(itemView);

            ematerial_date=itemView.findViewById(R.id.ematerial_post_date_tv);
            ematerial_sub=itemView.findViewById(R.id.ematerial_post_about_post_tv);
            ematerial_title=itemView.findViewById(R.id.ematerial_post_title_tv);
        }
    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.ematerial_post_activity,parent,false);
        return new MyViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {

        EmaterialUserModel ematerialUserModel=arrayList.get(position);
        holder.ematerial_title.setText(ematerialUserModel.getEmaterial_title());
        holder.ematerial_sub.setText(ematerialUserModel.getEmaterial_sub());
        holder.ematerial_date.setText(ematerialUserModel.getEmaterial_date());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


}
