package com.example.vrutik.myapplication;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class PostActivity_RecyclerView extends RecyclerView.Adapter<PostActivity_RecyclerView.Post_List_Activity> {

    private ArrayList<PostUserModel> arrayList;

    public PostActivity_RecyclerView(ArrayList<PostUserModel> arrayList) {
        this.arrayList = arrayList;
    }


    @NonNull
    @Override
    public Post_List_Activity onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.home_post_activity,parent,false);
        return new Post_List_Activity(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Post_List_Activity holder, int position) {

        PostUserModel postUserModel=arrayList.get(position);
        holder.post_text.setText(postUserModel.getTitle());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class Post_List_Activity extends RecyclerView.ViewHolder {

        ImageView post_image;
        TextView post_text;

        public Post_List_Activity(View itemView) {
            super(itemView);
            post_image=itemView.findViewById(R.id.post_main_img);
            post_text=itemView.findViewById(R.id.post_main_title);
        }
    }
}
