package com.example.vrutik.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class EmaterialActivity extends AppCompatActivity {

    private ArrayList<EmaterialUserModel> arrayList;
    private RecyclerView recyclerView;
    private EmaterialActivity_RecyclerView ematerialAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ematerial_activity);

        recyclerView=findViewById(R.id.ematerial_page_recycleview);

        arrayList=new ArrayList<EmaterialUserModel>();

        arrayList= new ArrayList<EmaterialUserModel>();

        arrayList.add(new EmaterialUserModel("January 11,2019",
                "Assignment","ANDROID"));
        arrayList.add(new EmaterialUserModel("December 01,2018",
                "Practical","PHP"));
        arrayList.add(new EmaterialUserModel("August 25,2018",
                "Chapter 1,2","JAVA"));
        arrayList.add(new EmaterialUserModel("January 24,2019",
                "Chapter 5","WNS"));


        ematerialAdapter = new EmaterialActivity_RecyclerView(arrayList);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(EmaterialActivity.this,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(ematerialAdapter);
    }
}
