package com.example.vrutik.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button login_btn;
    private Button signUp_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login_btn=findViewById(R.id.main_activity_login_btn);
        login_btn.setOnClickListener(this);

        signUp_btn=findViewById(R.id.main_activity_signup_btn);
        signUp_btn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.main_activity_login_btn:
                login_btn_event();
                break;

            case R.id.main_activity_signup_btn:
                signUp_btn_event();
                break;
        }

    }

    private void signUp_btn_event() {

        Intent gotoSignUpActivity = new Intent(MainActivity.this,SignUpActivity.class);
        startActivity(gotoSignUpActivity);
    }

    private void login_btn_event() {

        Intent gotoLoginActivity = new Intent(MainActivity.this,LoginActivity.class);
        startActivity(gotoLoginActivity);
    }
}
