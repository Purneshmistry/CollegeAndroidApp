package com.example.vrutik.myapplication;

public class EmaterialUserModel {


    private String ematerial_date;
    private String ematerial_sub;
    private String ematerial_title;

    public EmaterialUserModel(String ematerial_date, String ematerial_sub, String ematerial_title) {
        this.ematerial_date = ematerial_date;
        this.ematerial_sub = ematerial_sub;
        this.ematerial_title = ematerial_title;
    }

    public EmaterialUserModel() {
    }

    public String getEmaterial_date() {
        return ematerial_date;
    }

    public void setEmaterial_date(String ematerial_date) {
        this.ematerial_date = ematerial_date;
    }

    public String getEmaterial_sub() {
        return ematerial_sub;
    }

    public void setEmaterial_sub(String ematerial_sub) {
        this.ematerial_sub = ematerial_sub;
    }

    public String getEmaterial_title() {
        return ematerial_title;
    }

    public void setEmaterial_title(String ematerial_title) {
        this.ematerial_title = ematerial_title;
    }
}
