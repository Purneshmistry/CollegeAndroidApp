package com.example.vrutik.myapplication;

public class ResultUserModel {

    private String result_date;
    private String result_sem;
    private String result_title;

    public ResultUserModel(String result_date, String result_sem, String result_title) {
        this.result_date = result_date;
        this.result_sem = result_sem;
        this.result_title = result_title;
    }

    public ResultUserModel() {
    }

    public String getResult_date() {
        return result_date;
    }

    public void setResult_date(String result_date) {
        this.result_date = result_date;
    }

    public String getResult_sem() {
        return result_sem;
    }

    public void setResult_sem(String result_sem) {
        this.result_sem = result_sem;
    }

    public String getResult_title() {
        return result_title;
    }

    public void setResult_title(String result_title) {
        this.result_title = result_title;
    }
}
