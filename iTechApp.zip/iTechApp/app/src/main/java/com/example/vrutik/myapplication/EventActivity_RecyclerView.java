package com.example.vrutik.myapplication;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class EventActivity_RecyclerView extends RecyclerView.Adapter<EventActivity_RecyclerView.MyViewHolder> {

    private ArrayList <EventUserModel> arrayList;

    public EventActivity_RecyclerView(ArrayList <EventUserModel> arrayList) {
        this.arrayList = arrayList;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView post_date;
        private TextView post_title;
        private TextView post_month;
        private TextView post_description;
        public MyViewHolder(View itemView) {
            super(itemView);

            post_month=itemView.findViewById(R.id.event_month_tv);
            post_date=itemView.findViewById(R.id.event_date_tv);
            post_title=itemView.findViewById(R.id.event_title_tv);
            post_description=itemView.findViewById(R.id.event_description_tv);
        }
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_post_activity,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        EventUserModel eventUserModel=arrayList.get(position);
        holder.post_month.setText(eventUserModel.getEvent_month());
        holder.post_date.setText(eventUserModel.getEvent_date());
        holder.post_title.setText(eventUserModel.getEvent_title());
        holder.post_description.setText(eventUserModel.getEvent_description());

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


}
